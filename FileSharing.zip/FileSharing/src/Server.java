import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) throws Exception {
        int port = 3000;
        ServerSocketChannel listenChannel = ServerSocketChannel.open();
        listenChannel.bind(new InetSocketAddress(port));

        while (true) {
            SocketChannel serveChannel = listenChannel.accept();
            ByteBuffer request = ByteBuffer.allocate(1024);
            int bytesRead = serveChannel.read(request);
            request.flip();
            byte[] a = new byte[1];
            request.get(a);
            String command = new String(a);
            switch (command) {
                case "x":
                    byte[] b = new byte[request.remaining()];
                    request.get(b);
                    String fileName = new String(b);
                    File deleteFile = new File("C:\\Users\\tyfsa\\OneDrive\\Documents\\Ball State\\2024 Fall\\Intro to OS\\Packet Sharing\\FileSharing\\src\\Uploaded Files\\" + fileName);
                    boolean success = false;
                    if (deleteFile.exists()) {
                        System.out.println("File to delete" + fileName);
                        success = deleteFile.delete();
                    }
                    if (success) {
                        System.out.println("File deleted successfully");
                        ByteBuffer code = ByteBuffer.wrap("S".getBytes());
                        serveChannel.write(code);
                    } else {
                        System.out.println("Unable to delete file");
                        ByteBuffer code = ByteBuffer.wrap("F".getBytes());
                        serveChannel.write(code);
                    }
                    break;
                case "d":
                    byte[] d = new byte[request.remaining()];
                    request.get(d);
                    String downloadFileName = new String(d);
                    System.out.println("File to send" + downloadFileName);
                    File sendFile = new File("C:\\Users\\tyfsa\\OneDrive\\Documents\\Ball State\\2024 Fall\\Intro to OS\\Packet Sharing\\FileSharing\\src\\Uploaded Files\\" + downloadFileName);


                    boolean dlSuccess = false;
                    if (sendFile.exists()) {
                        dlSuccess = true;
                    }
                    if (dlSuccess) {
                        System.out.println("File exists");
                        ByteBuffer code = ByteBuffer.wrap("S".getBytes());
                        serveChannel.write(code);
                    } else {
                        System.out.println("Unable to find file");
                        ByteBuffer code = ByteBuffer.wrap("F".getBytes());
                        serveChannel.write(code);
                    }

                    FileInputStream fis = new FileInputStream(sendFile);
                    byte[] data = new byte[1024];
                    int dlBytesRead = 0;
                    while((dlBytesRead=fis.read(data)) != -1) {
                        ByteBuffer buffer = ByteBuffer.wrap(data, 0, dlBytesRead);
                        serveChannel.write(buffer);
                    }
                    fis.close();
                    serveChannel.shutdownOutput();
                    break;

                case "r":
                    byte[] c = new byte[request.remaining()];
                    request.get(c);
                    String byteString = new String(c);

                    String oldFileName = null;
                    String newFileName = null;

                    String[] parts = byteString.split("&&");
                    if (parts.length == 2) {
                        oldFileName = parts[0];
                        newFileName = parts[1];
                    }

                    System.out.println("File to rename: " + oldFileName);


                    File oldFile = new File("C:\\Users\\tyfsa\\OneDrive\\Documents\\Ball State\\2024 Fall\\Intro to OS\\Packet Sharing\\FileSharing\\src\\Uploaded Files\\" + oldFileName);
                    File newFile = new File("C:\\Users\\tyfsa\\OneDrive\\Documents\\Ball State\\2024 Fall\\Intro to OS\\Packet Sharing\\FileSharing\\src\\Uploaded Files\\" + newFileName);

                    boolean renameSuccess = false;
                    if (oldFile.exists()) {
                        renameSuccess = oldFile.renameTo(newFile);
                    }

                    if (renameSuccess) {
                        System.out.println("File renamed successfully");
                        ByteBuffer code = ByteBuffer.wrap("S".getBytes());
                        serveChannel.write(code);
                    } else {
                        System.out.println("Unable to rename file");
                        ByteBuffer code = ByteBuffer.wrap("F".getBytes());
                        serveChannel.write(code);
                    }
                    break;

                case "u":
                    byte[] u = new byte[request.remaining()];
                    request.get(u);
                    String fileString = new String(u);

                    String commandString = null;
                    String uploadFileName = null;

                    String[] part = fileString.split("&&");
                    if (part.length == 2) {
                        commandString = part[0];
                        uploadFileName = part[1];
                    }

                    // Create the output stream in the ServerFiles directory
                    String filePath = "C:\\Users\\tyfsa\\OneDrive\\Documents\\Ball State\\2024 Fall\\Intro to OS\\Packet Sharing\\FileSharing\\src\\Uploaded Files\\" + uploadFileName; // Use the original filename
                    try (FileOutputStream fos = new FileOutputStream(filePath)) {
                        ByteBuffer buffer = ByteBuffer.allocate(1024);
                        int uploadBytesRead;
                        // Read the file data
                        while ((uploadBytesRead = serveChannel.read(buffer)) !=  -1) {
                            buffer.flip();
                            byte[] u1 = new byte[uploadBytesRead];
                            buffer.get(u1);
                            fos.write(u1);
                            buffer.clear();
                        }
                        fos.close();

                        System.out.println("File recieved: " + filePath);

                        String replyMessage = "S";
                        ByteBuffer replyBuffer =
                                ByteBuffer.wrap(replyMessage.getBytes());
                        serveChannel.write(replyBuffer);
                        serveChannel.close();
                    }
                    break;
                case "l":
                    String list = GetList();
                    System.out.println(list);

                    ByteBuffer code = ByteBuffer.wrap(list.getBytes());
                    serveChannel.write(code);

                    break;
                default:
                    System.out.println("Invalid command");
            }//Switch
        }//While
    }

    static String GetList(){
        String folderPath = "C:\\Users\\tyfsa\\OneDrive\\Documents\\Ball State\\2024 Fall\\Intro to OS\\Packet Sharing\\FileSharing\\src\\Uploaded Files";

        File folder = new File(folderPath);

        File[] listOfFiles = folder.listFiles();
        StringBuilder fileList = new StringBuilder();

        if (listOfFiles != null) {
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    fileList.append(file.getName()).append("\n");
                }
            }
        } else {
            fileList.append("No files found in folder");
        }

        String fileListString = fileList.toString();
        return fileListString;

    }
}//Class Server


