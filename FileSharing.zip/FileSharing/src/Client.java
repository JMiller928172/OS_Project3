import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client{
    static boolean isFinished = true;

    public static void main(String[] args) throws Exception {
        if (args.length != 2){
            System.out.println("Please provide <serverIP> and <serverPort>");
            return;
        }
        int serverPort = Integer.parseInt(args[1]);
        Scanner keyboard = new Scanner(System.in);


        while (isFinished) {
            System.out.println("Type a command. Type h for help. Type e to end.");
            String command = keyboard.nextLine();

            switch (command) {
                case "h":
                    System.out.println("This is a list of commands you can use:" +
                            "\n 'x' delete" +
                            "\n 'u' upload" +
                            "\n 'r' rename " +
                            "\n 'l' list files" +
                            "\n 'd' download file" +
                            "\n 'e' exit");
                    break;
                case "x":
                    //Class code
                    System.out.println("What file do you want to delete?");
                    String fileName = keyboard.nextLine();
                    ByteBuffer request = ByteBuffer.wrap((command + fileName).getBytes());
                    SocketChannel channel = SocketChannel.open();
                    channel.connect(new InetSocketAddress(args[0], serverPort));
                    channel.write(request);
                    channel.shutdownOutput();
                    // delete(filename);
                    //TODO receive the status code and tell the user
                    //Class Code
                    ByteBuffer reply = ByteBuffer.allocate(1);
                    channel.read(reply);
                    channel.close();
                    reply.flip();
                    byte[] a = new byte[1];
                    reply.get(a);
                    String code = new String(a);
                    if (code.equals("S")) {
                        System.out.println("File successfully deleted.");
                    } else if (code.equals("F")) {
                        System.out.println("Failed to delete file.");
                    } else {
                        System.out.println("Invalid server code received.");
                    }
                    //
                    break;
                case "u":
                    System.out.println("Enter the file location to upload:");
                    String fileLocation = keyboard.nextLine();
                    File uploadFile =  new File(fileLocation);

                    if (uploadFile.exists()) {
                        System.out.println("The file exists: " + fileLocation);
                        String serverIP = args[0];
                        try {
                            PrepareForUpload(fileLocation, serverIP, serverPort);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    } else {
                        System.out.println("The file does not exist: " + fileLocation);
                    }

                    break;
                case "e":
                    isFinished = false;
                    break;
                case "l":
                    ByteBuffer listRequest = ByteBuffer.wrap((command).getBytes());
                    SocketChannel listChannel = SocketChannel.open();
                    listChannel.connect(new InetSocketAddress(args[0], serverPort));
                    listChannel.write(listRequest);
                    listChannel.shutdownOutput();

                    ByteBuffer listReply = ByteBuffer.allocate(1024);
                    StringBuilder listResponse = new StringBuilder();
                    int listBytesRead;

                    while ((listBytesRead = listChannel.read(listReply)) > 0) {
                        listReply.flip();
                        byte[] bytes = new byte[listReply.remaining()];
                        listReply.get(bytes);
                        System.out.println(new String(bytes));
                    }

                    listChannel.close();
                    break;

                case "r":
                    System.out.println("What file do you want to rename?");
                    String renameFileName = keyboard.nextLine();

                    System.out.println("What would you like to change the name to?");
                    String newFileName = keyboard.nextLine();

                    ByteBuffer renameRequest = ByteBuffer.wrap((command + renameFileName + "&&" + newFileName).getBytes());
                    SocketChannel renameChannel = SocketChannel.open();
                    renameChannel.connect(new InetSocketAddress(args[0], serverPort));
                    renameChannel.write(renameRequest);
                    renameChannel.shutdownOutput();
                    ByteBuffer renameReply = ByteBuffer.allocate(1);
                    renameChannel.read(renameReply);
                    renameChannel.close();

                    renameReply.flip();
                    byte [] r = new byte[1];
                    renameReply.get(r);
                    String renameCode = new String(r);
                    if (renameCode.equals("S")){
                        System.out.println("File successfully renamed.");
                    } else if (renameCode.equals("F")){
                        System.out.println("Failed to rename file.");
                    }else{
                        System.out.println("Invalid server code received.");
                    }
                    break;

                case "d":
                    System.out.println("What file do you want to download?");
                    String downloadFileName = keyboard.nextLine();

                    System.out.println("Where would you like to save the file?");
                    String downloadFileLocation = keyboard.nextLine();

                    System.out.println("What would you like to name the file?");
                    String downloadedFileName = keyboard.nextLine();

                    ByteBuffer downloadRequest = ByteBuffer.wrap((command + downloadFileName).getBytes());
                    SocketChannel dlChannel = SocketChannel.open();
                    dlChannel.connect(new InetSocketAddress(args[0], serverPort));
                    dlChannel.write(downloadRequest);
                    dlChannel.shutdownOutput();
                    ByteBuffer downloadReply = ByteBuffer.allocate(1);
                    dlChannel.read(downloadReply);

                    FileOutputStream fos = new FileOutputStream(downloadFileLocation + "\\" + downloadedFileName);

                    ByteBuffer buffer = ByteBuffer.allocate(1024);
                    int dlBytesRead;
                    while ((dlBytesRead = dlChannel.read(buffer)) != -1) {
                        buffer.flip();
                        byte[] data = new byte[dlBytesRead];
                        buffer.get(data);
                        fos.write(data);
                        buffer.clear();
                    }
                    System.out.println("File received and saved successfully!");

                    dlChannel.close();
                    break;
                default:
                    System.out.println("Unknown command. Type h for help.");
                    break;
            }
        }
        keyboard.close();
    }

    public static void PrepareForUpload(String fileLocation, String serverIP, int serverPort) throws IOException {
        SocketChannel channel = SocketChannel.open();
        channel.connect(new InetSocketAddress(serverIP, serverPort));

        System.out.println("Name the uploaded file.");
        Scanner scanner = new Scanner(System.in);
        String newFileName = scanner.nextLine();

        String command = "u&&" + newFileName;


        byte[] commandBytes = command.getBytes();

        FileInputStream fis = new FileInputStream(fileLocation);
        byte[] data = new byte[1024];
        int bytesRead = 0;

        // First, send the command
        ByteBuffer commandBuffer = ByteBuffer.wrap(commandBytes);
        channel.write(commandBuffer);

        // Then, send the file data
        while ((bytesRead = fis.read(data)) != -1) {
            ByteBuffer buffer = ByteBuffer.wrap(data, 0, bytesRead);
            channel.write(buffer);
        }
        fis.close();
        channel.shutdownOutput();

        //receive
        ByteBuffer replyBuffer = ByteBuffer.allocate(1);
        channel.read(replyBuffer);
        replyBuffer.flip();
        byte[] b = new byte[1];
        replyBuffer.get(b);
        String code = new String(b);
        if (code.equals("S")){
            System.out.println("File successfully uploaded.");
        } else if (code.equals("F")){
            System.out.println("Failed to upload file.");
        }else{
            System.out.println("Invalid server code received.");
        }

        channel.close();


        //File oldFile = new File("C:\\Users\\tyfsa\\OneDrive\\Documents\\Ball State\\2024 Fall\\Intro to OS\\Packet Sharing\\FileSharing\\src\\Uploaded Files\\newUpload");
       // File newFile = new File("C:\\Users\\tyfsa\\OneDrive\\Documents\\Ball State\\2024 Fall\\Intro to OS\\Packet Sharing\\FileSharing\\src\\Uploaded Files\\" + newFileName);

        //boolean renameSuccess = false;
        //if (oldFile.exists()) {
            //renameSuccess = oldFile.renameTo(newFile);
        //}
    }
}